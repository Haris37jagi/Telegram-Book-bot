# Telegram Book Bot

This is a simple Telegram bot that shares PDF books using Python.

## Commands:
- /start → Show book list

## Hosting (Render):
- Build command: pip install -r requirements.txt
- Start command: python bot.py
- Add Environment Variable: BOT_TOKEN
