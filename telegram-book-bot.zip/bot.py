import telebot
from telebot import types
import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    books = [f for f in os.listdir("books") if f.endswith(".pdf")]
    if not books:
        bot.send_message(message.chat.id, "❌ No books found in the folder.")
        return

    for book in books:
        markup.add(types.KeyboardButton(book))

    bot.send_message(
        message.chat.id,
        "👋 Welcome to BookFinder Bot!\n\nChoose a book to download:",
        reply_markup=markup
    )

@bot.message_handler(func=lambda message: True)
def send_book(message):
    book_name = message.text.strip()
    book_path = os.path.join("books", book_name)
    if os.path.exists(book_path):
        with open(book_path, "rb") as f:
            bot.send_document(message.chat.id, f)
    else:
        bot.send_message(message.chat.id, "❌ Book not found.")

print("✅ Bot is running...")
bot.polling()
