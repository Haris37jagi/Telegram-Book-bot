# Telegram Book Bot

This is a Telegram bot that shares English PDF books with categories.

## Categories:
- English Books
- Urdu Novels
- Islamic Books
- Python Books

## Hosting:
- Platform: Render.com
- Build command: pip install -r requirements.txt
- Start command: python bot.py
- Environment Variable: BOT_TOKEN (from @BotFather)
